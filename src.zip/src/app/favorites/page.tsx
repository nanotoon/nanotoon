'use client'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import { useState, useEffect, useMemo } from 'react'
import { SeriesCard } from '@/components/SeriesCard'
import { useToast } from '@/components/Toast'
import { createAnonClient } from '@/lib/supabase/anon'
import { useAuth } from '@/contexts/AuthContext'
import { latestRating } from '@/lib/seriesRating'
import { hydrateSeriesCounts } from '@/lib/hydrateSeriesCounts'
import { TIME_WINDOWS, timeWindowSince, type TimeWindow } from '@/lib/timeWindow'

export default function FavoritesPage() {
  const { user, loading: authLoading } = useAuth()
  const { show } = useToast()
  const supabase = useMemo(() => createAnonClient(), [])
  const [favorites, setFavorites] = useState<any[]>([])
  const [formatFilter, setFormatFilter] = useState('All')
  const [timeFilter, setTimeFilter] = useState<TimeWindow>('All Time')
  const [loading, setLoading] = useState(true)
  // FIX: View More on the favorites grid. Grid is 9-per-row PC / 3-per-row
  // mobile (same as home), so caps and step size match home: 45 PC max /
  // 27 mobile max, +18 PC / +6 mobile per press. Seed at 0 so the
  // mount-time effect picks the right value once isMobile resolves.
  const [isMobile, setIsMobile] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [visibleCount, setVisibleCount] = useState(0)

  useEffect(() => {
    function check() { setIsMobile(window.innerWidth < 768) }
    check()
    setMounted(true)
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [])

  // Seed visibleCount once isMobile resolves on mount.
  useEffect(() => {
    if (!mounted) return
    if (visibleCount === 0) setVisibleCount(isMobile ? 27 : 45)
  }, [mounted, isMobile, visibleCount])

  // Reset View More when a filter changes — same UX as the other tabs.
  useEffect(() => {
    if (!mounted) return
    setVisibleCount(isMobile ? 27 : 45)
  }, [formatFilter, timeFilter, mounted, isMobile])

  useEffect(() => {
    // Wait for auth to finish before doing anything
    if (authLoading) return

    if (!user) {
      setLoading(false)
      return
    }

    let cancelled = false

    // Hard timeout — never spin forever
    const timeout = setTimeout(() => {
      if (!cancelled) setLoading(false)
    }, 8000)

    async function load() {
      try {
        const { data } = await supabase
          .from('favorites')
          .select('*, series(*, profiles!series_author_id_fkey(display_name, handle, avatar_url), chapters(rating, chapter_number))')
          .eq('user_id', user!.id)
          .order('created_at', { ascending: false }) as { data: any[] | null }
        clearTimeout(timeout)
        if (!cancelled) {
          // Hydrate real like/favorite counts on the nested series objects so
          // the cards here match the series-page float menu and user profile.
          const rows = data ?? []
          const seriesList = rows.map(r => r.series).filter(Boolean)
          const hydrated = await hydrateSeriesCounts(supabase, seriesList as any[])
          const byId = new Map<string, any>(hydrated.map((s: any) => [s.id, s]))
          const merged = rows.map(r => r.series ? { ...r, series: byId.get(r.series.id) ?? r.series } : r)
          setFavorites(merged)
          setLoading(false)
        }
      } catch {
        clearTimeout(timeout)
        if (!cancelled) setLoading(false)
      }
    }
    load()

    return () => {
      cancelled = true
      clearTimeout(timeout)
    }
  }, [user, authLoading, supabase])

  return (
    <div className="px-4 md:px-8 py-6">
      <h2 className="text-base font-semibold text-[#c084fc] mb-4">Your Favorites</h2>
      {user && !loading && favorites.length > 0 && (
        // Read-tab-style header: format pills on the left, time pills on the
        // right. `justify-between` + `flex-wrap` matches the Most Viewed row
        // on the home page so PC and mobile placement stay consistent —
        // pills sit side-by-side on desktop and stack on narrow screens.
        <div className="flex items-center justify-between mb-5 flex-wrap gap-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[0.75rem] text-[#71717a] shrink-0">Show:</span>
            {['All', 'Series', 'One Shot'].map(f => (
              <button key={f} onClick={() => setFormatFilter(f)}
                className={`px-3 py-1 rounded-full text-[0.73rem] cursor-pointer border transition-all ${formatFilter === f ? 'bg-[#7c3aed] border-[#7c3aed] text-white' : 'bg-transparent border-[#3f3f46] text-[#71717a] hover:border-[#a855f7] hover:text-[#c084fc]'}`}>{f}</button>
            ))}
          </div>
          <div className="flex gap-1.5 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
            {TIME_WINDOWS.map(t => (
              <button key={t} onClick={() => setTimeFilter(t)}
                className={`px-3 py-1 rounded-full text-[0.73rem] cursor-pointer border whitespace-nowrap transition-all ${timeFilter === t ? 'bg-[#7c3aed] border-[#7c3aed] text-white' : 'bg-transparent border-[#3f3f46] text-[#71717a] hover:border-[#a855f7] hover:text-[#c084fc]'}`}>{t}</button>
            ))}
          </div>
        </div>
      )}
      {loading ? (
        <LoadingSpinner />
      ) : !user ? (
        <p className="text-center py-16 text-[#71717a]">Sign in to see your favorites.</p>
      ) : favorites.length === 0 ? (
        <p className="text-center py-16 text-[#71717a]">
          No favorites yet.<br />
          <span className="text-sm block mt-2">Start reading and tap Favorite inside a series!</span>
        </p>
      ) : (() => {
        // Compute the filtered list ONCE so the grid and the View More
        // button can both reference the full filtered length.
        //
        // Time filter on this tab is "when I favorited it" — the favorites
        // row's created_at — not the series' updated_at. Users browsing
        // their favorites by time are asking "what did I add recently," not
        // "which of my favorites got updated recently."
        const since = timeWindowSince(timeFilter)
        const filtered = favorites.filter(f =>
          f.series && !f.series.is_removed
          && (formatFilter === 'All' || f.series.format === formatFilter)
          && (!since || (f.created_at && f.created_at >= since))
        )
        const visible = filtered.slice(0, visibleCount || (isMobile ? 27 : 45))
        return (
          <>
            <div className="grid gap-2.5 md:gap-4 grid-cols-3 md:grid-cols-9">
              {visible.map((f, i) => (
                <SeriesCard
                  key={f.series.id}
                  title={f.series.title}
                  slug={f.series.slug}
                  author={f.series.profiles?.display_name || 'Unknown'}
                  thumbnailUrl={f.series.thumbnail_url}
                  latestChapter={0}
                  rating={latestRating(f.series.chapters)}
                  format={f.series.format}
                  index={i}
                  views={f.series.total_views}
                  likes={f.series.total_likes}
                  favorites={f.series.total_favorites}
                />
              ))}
            </div>
            {/* View More — mobile-aware increment (+6 mobile / +18 PC).
                Hidden once all filtered favorites are already visible. */}
            {filtered.length > visible.length && (
              <div className="flex justify-center mt-7">
                <button onClick={() => { setVisibleCount(c => c + (isMobile ? 6 : 18)); show('Loaded more!') }}
                  className="px-7 py-2.5 border border-[#3f3f46] rounded-xl bg-transparent text-[#a1a1aa] cursor-pointer text-sm hover:border-[#a855f7] hover:text-[#c084fc]">View More</button>
              </div>
            )}
          </>
        )
      })()}
    </div>
  )
}
